DROP TABLE IF EXISTS `#__vdb_opportunities`;
DROP TABLE IF EXISTS `#__vdb_causes`;
DROP TABLE IF EXISTS `#__vdb_cause_categories`;
DROP TABLE IF EXISTS `#__vdb_locations`;
DROP TABLE IF EXISTS `#__vdb_admins`;
DROP TABLE IF EXISTS `#__vdb_organizations`;
DROP TABLE IF EXISTS `#__vdb_skills`;
DROP TABLE IF EXISTS `#__vdb_skill_categories`;