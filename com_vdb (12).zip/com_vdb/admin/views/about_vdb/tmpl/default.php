<?php defined('_JEXEC') or die('Restricted access'); ?>
<style>
    .about_sponsorwall td
    {
        padding:5px!important;
        font-family: Century Gothic !important;
        font-weight: normal !important;
        font-size: 13px !important ;
    }
</style>
<table class="about_sponsorwall" align="left" style="width:550px !important;background-color:#F9F1F1;border:1px solid silver;">

    <tr align="left" style="font-size: 16px;">
        <td align="left" style="width: 15%;border-bottom: 1px solid silver;">
            <img alt="SponsorWall" src="components/com_sponsorwall/images/sponsor_wall.png" style="height:75px;width:75px;border:1px black solid;"/>
        </td>
        <td align="left" style="padding-left:0px !important;
            border-bottom: 1px solid silver;
            vertical-align: middle;">
            <div style="text-transform:uppercase ;font-weight:bold;font-size: 18px;color: rgb(103,103,251);">Sponsor Wall</div>
            <div>
                Current Version 2.7
            </div>
            <div> <a style="" href="http://extensions.joomla.org/extensions/ads-a-affiliates/sponsors/13080" target="_new">
                    Check About Update
                </a>
            </div>

        </td>

    </tr>

    <tr style="        font-family:verdana !important;
        font-size:16px !important;
        ">

        <td colspan="2" align="left" style="margin-top:10px !important;border-bottom: 1px solid silver;">
            You have any query or problem then please create ticket with <a href="http://www.pulseextensions.com/support" target="_new">Our Support Center</a>
        </td>
    </tr>
    <tr style="font-family:verdana !important;font-size:16px !important;text-align: left">
        <td align="left" colspan="2">
            CopyRight &copy; 2007 - 2013 <a href="http://www.pulseextensions.com" target="_new">Pulse Extension Team</a>
        </td>


    </tr>


</table>
